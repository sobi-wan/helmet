#!/usr/bin/python

import sys

print 'Number of arguments:', len(sys.argv), 'arguments.'
print 'Argument list:', str(sys.argv)
print 'Just arg1:', str(sys.argv[1])
